
# Student Management System
## Language used : Python
## Database : MySql
## Moduls : Tkinter, pymysql, time, pandas  

#### pip install pymysql
#### pip install pandas
### DataBase.py -> this file include  a class to perform simple operations (i.e insert, delete, show, update) on database
### studentmanagement.py -> this file include complete GUI and code to perform operations
